#include <stdio.h>

int main()
{
    int n;
    printf("Enter n");
    scanf("%d",&n);
    int A[n];
    printf("Enter array");
    for(int i=0;i<n;i++)
    {
        scanf("%d",&A[i]);
        
    }
        
    for(int i=0;i<n;i++)
    {
      for(int j=0;j<n-1;j++)
      {
          if(A[j]>A[j+1])
          {
              int temp;
              temp = A[j];
              A[j] = A[j+1];
              A[j+1] = temp;
          }
      }
    }
    for(int i=0;i<n;i++)
    {
        printf("%d",A[i]);
        
    }
    
    for (int z=0;z<n;z++)
    {
            if(A[z]==A[z+1])
            {
                printf("Duplicaate is %d",A[z]);
            }
    }

    return 0;
}
